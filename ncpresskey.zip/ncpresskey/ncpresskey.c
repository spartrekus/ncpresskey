

#include <stdio.h> 

int main(){ 
    printf( "<Press Return to Continue>\n" ); 
    getchar();
    return 0; 
}  




























